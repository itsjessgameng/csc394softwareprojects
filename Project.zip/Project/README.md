# csc394softwareprojects

To start environment: 

	1. cd to env 
	2. run $source bin/activate

To view app on local host: 

	1. cd to src directory with manage.py file 
	2. run $python manage.py runserver 
	3. browser: localhost:8000 

Login: 

	Admin
	Username: admin
	Password: admin123

	Student 
	Username: stu1
	Password: student123


