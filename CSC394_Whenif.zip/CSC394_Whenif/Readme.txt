Superusername: csc394
password: csc394csc394